<div class="form-group {{ $errors->has('image') ? 'has-error' : ''}}">
    <label for="image" class="control-label">{{ 'Image' }} {{ isset($product) ? '' : '*'}}</label>
    <input class="form-control" name="image" type="file" id="image" {{ isset($product) ? '' : 'required'}} value="{{ isset($product->image) ? $product->image : ''}}">
    {!! $errors->first('image', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('name') ? 'has-error' : ''}}">
    <label for="name" class="control-label">{{ 'Name *' }}</label>
    <input class="form-control" name="name" type="text" id="name" value="{{ isset($product->name) ? $product->name : ''}}">
    {!! $errors->first('name', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('category_id') ? 'has-error' : ''}}">
    <label for="category_id" class="control-label">{{ 'Category *' }}</label>

    <select class="form-control" name="category_id">
        @php
            $categories = \App\Models\Category::where('status', 1)->get();
        @endphp
        @foreach($categories as $item)
            <option value="{{ $item->id }}" {{ (isset($product->category_id) && $product->category_id == $item->id) ? 'selected' : '' }}>{{ $item->name }}</option>
        @endforeach
    </select>

    {!! $errors->first('category_id', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('company_id') ? 'has-error' : ''}}">
    <label for="company_id" class="control-label">{{ 'Company *' }}</label>
    <select class="form-control" name="company_id">
        @php
            $company = \App\Models\Company::where('status', 1)->get();
        @endphp
        @foreach($company as $item)
            <option value="{{ $item->id }}" {{ (isset($product->category_id) && $product->category_id == $item->id) ? 'selected' : '' }}>{{ $item->name }}</option>
        @endforeach
    </select>

    {!! $errors->first('company_id', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('price') ? 'has-error' : ''}}">
    <label for="price" class="control-label">{{ 'Price *' }}</label>
    <input class="form-control" name="price" type="number" id="price" value="{{ isset($product->price) ? $product->price : ''}}" step="any">
    {!! $errors->first('price', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('discount_price') ? 'has-error' : ''}}">
    <label for="discount_price" class="control-label">{{ 'Discount Price' }}</label>
    <input class="form-control" name="discount_price" type="number" id="discount_price" step="any"
           value="{{ isset($product->discount_price) ? $product->discount_price : ''}}">
    {!! $errors->first('discount_price', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('discount_percentage') ? 'has-error' : ''}}">
    <label for="discount_percentage" class="control-label">{{ 'Discount Percentage' }}</label>
    <input class="form-control" name="discount_percentage" type="number" id="discount_percentage" step="any"
           value="{{ isset($product->discount_percentage) ? $product->discount_percentage : ''}}">
    {!! $errors->first('discount_percentage', '<p class="help-block">:message</p>') !!}
</div>

<div class="form-group {{ $errors->has('status') ? 'has-error' : ''}}">
    <label for="status" class="control-label">{{ 'Status *' }}</label>
    <select class="form-control" name="status">
        <option value="1" {{ (isset($product->status) && $product->status == 1) ? 'selected' : '' }}>Active</option>
        <option value="0" {{ (isset($product->status) && $product->status == 0) ? 'selected' : '' }}>InActive</option>
    </select>
    {!! $errors->first('status', '<p class="help-block">:message</p>') !!}
</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="{{ $formMode === 'edit' ? 'Update' : 'Create' }}">
</div>
