<?php $__env->startSection('css'); ?>
    <style>
        @media print {
            @page {
                margin: 15px;
                padding: 10px 20px;
            }

            .no-print, .no-print * {
                display: none !important;
            }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Delivery Invoice List</div>
                    <div class="card-body">

                        <form method="GET">
                            <div class="row">
                                <div class="form-group col-lg-3 col-sm-6 col-12">
                                    <lable>Select Area</lable>
                                    <select class="form-control" name="area">
                                        <option value="">All Area</option>
                                        <?php $__currentLoopData = $area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                value="<?php echo e($item->id); ?>" <?php echo e((isset($search_area) && $search_area == $item->id) ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group col-lg-3 col-sm-6 col-12">
                                    <lable>Date</lable>
                                    <input type="date" class="form-control" name="date" value="<?php echo e(isset($date) ? $date : ''); ?>">
                                </div>

                                <div class="form-group col-lg-1 col-sm-3 col-12">
                                    <lable>Show</lable>
                                    <input type="number" class="form-control" name="pagination" min="1" value="<?php echo e(isset($pagination) ? $pagination : ''); ?>">
                                </div>
                                <div class="col-lg-1 col-sm-6 col-12">
                                    <button type="submit" class="btn btn-primary" style="margin-top: 20px">Submit</button>
                                </div>
                            </div>
                        </form>

                        <button class="btn btn-primary float-end" onclick="print_invoice()">Print</button>
                        <br/>
                        <br/>

                        <div id="print_section">
                            <?php if($date): ?>
                                <p style="padding: 0px 10px; font-size: 20px">
                                    <span> <b>Area : </b> <?php echo e((isset($area_name)) ? $area_name : ''); ?></span>
                                    <span style="float: right;"> <b>Date : </b> <?php echo e($date); ?></span>
                                </p>
                            <?php endif; ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Address</th>
                                        <th>Number</th>
                                        <th>Amount</th>
                                        <th class="no-print">Actions</th>
                                        <th class="no-print">Order Created</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $order_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td>
                                                <b>Name: </b><?php echo e($item->user_name); ?>

                                                <br>
                                                <?php echo e($item->address); ?>

                                            </td>
                                            <td><?php echo e($item->user_phone); ?></td>
                                            <td><?php echo e($item->total); ?> TK</td>
                                            <td class="no-print">

                                                <?php if($status == 'Pending'): ?>
                                                    <a href="<?php echo e(route('order_approve', $item->id)); ?>" class="btn btn-primary btn-sm"><i
                                                            class="fa fa-pencil-square-o" aria-hidden="true"></i> Approved</a>

                                                    <a href="<?php echo e(route('order_cancel', $item->id)); ?>" class="btn btn-secondary btn-sm"><i
                                                            class="fa fa-pencil-square-o" aria-hidden="true"></i> Cancel</a>
                                                <?php endif; ?>

                                                <?php if($status == 'Approved'): ?>
                                                    <a href="<?php echo e(route('order_delivered', $item->id)); ?>" class="btn btn-primary btn-sm"><i
                                                            class="fa fa-pencil-square-o" aria-hidden="true"></i> Delivered</a>
                                                <?php endif; ?>

                                                <a href="<?php echo e(route('order_invoice', $item->id)); ?>" title="Details">
                                                    <button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Details
                                                    </button>
                                                </a>
                                            </td>
                                            <td class="no-print">
                                                <?php echo e($item->created_at->format('d-M-Y h:i:s a')); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="pagination-wrapper"> <?php echo $order_list->appends(request()->query())->render(); ?> </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function print_invoice() {
            var printContents = document.getElementById('print_section').innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sohan\Backup\medisource\medisource\resources\views/backend/orders/delivery_invoice.blade.php ENDPATH**/ ?>