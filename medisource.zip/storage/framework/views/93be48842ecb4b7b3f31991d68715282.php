<div class="form-group <?php echo e($errors->has('image') ? 'has-error' : ''); ?>">
    <label for="image" class="control-label"><?php echo e('Image'); ?> <?php echo e(isset($product) ? '' : '*'); ?></label>
    <input class="form-control" name="image" type="file" id="image" <?php echo e(isset($product) ? '' : 'required'); ?> value="<?php echo e(isset($product->image) ? $product->image : ''); ?>">
    <?php echo $errors->first('image', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <label for="name" class="control-label"><?php echo e('Name *'); ?></label>
    <input class="form-control" name="name" type="text" id="name" value="<?php echo e(isset($product->name) ? $product->name : ''); ?>">
    <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('category_id') ? 'has-error' : ''); ?>">
    <label for="category_id" class="control-label"><?php echo e('Category *'); ?></label>

    <select class="form-control" name="category_id">
        <?php
            $categories = \App\Models\Category::where('status', 1)->get();
        ?>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php echo e((isset($product->category_id) && $product->category_id == $item->id) ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <?php echo $errors->first('category_id', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('company_id') ? 'has-error' : ''); ?>">
    <label for="company_id" class="control-label"><?php echo e('Company *'); ?></label>
    <select class="form-control" name="company_id">
        <?php
            $company = \App\Models\Company::where('status', 1)->get();
        ?>
        <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php echo e((isset($product->category_id) && $product->category_id == $item->id) ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <?php echo $errors->first('company_id', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
    <label for="price" class="control-label"><?php echo e('Price *'); ?></label>
    <input class="form-control" name="price" type="number" id="price" value="<?php echo e(isset($product->price) ? $product->price : ''); ?>" step="any">
    <?php echo $errors->first('price', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('discount_price') ? 'has-error' : ''); ?>">
    <label for="discount_price" class="control-label"><?php echo e('Discount Price'); ?></label>
    <input class="form-control" name="discount_price" type="number" id="discount_price" step="any"
           value="<?php echo e(isset($product->discount_price) ? $product->discount_price : ''); ?>">
    <?php echo $errors->first('discount_price', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('discount_percentage') ? 'has-error' : ''); ?>">
    <label for="discount_percentage" class="control-label"><?php echo e('Discount Percentage'); ?></label>
    <input class="form-control" name="discount_percentage" type="number" id="discount_percentage" step="any"
           value="<?php echo e(isset($product->discount_percentage) ? $product->discount_percentage : ''); ?>">
    <?php echo $errors->first('discount_percentage', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
    <label for="status" class="control-label"><?php echo e('Status *'); ?></label>
    <select class="form-control" name="status">
        <option value="1" <?php echo e((isset($product->status) && $product->status == 1) ? 'selected' : ''); ?>>Active</option>
        <option value="0" <?php echo e((isset($product->status) && $product->status == 0) ? 'selected' : ''); ?>>InActive</option>
    </select>
    <?php echo $errors->first('status', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH D:\sohan\Backup\medisource\medisource\resources\views/backend/product/form.blade.php ENDPATH**/ ?>