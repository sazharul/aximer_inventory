<div class="form-group <?php echo e($errors->has('category_id') ? 'has-error' : ''); ?>">
    <label for="category_id" class="control-label"><?php echo e('Category Id'); ?></label>
    <?php
        $category_list = \App\Models\ExpenseCategory::where('status', 1)->orderBy('name')->get();
    ?>
    <select class="form-control" name="category_id" required>
        <?php $__currentLoopData = $category_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option
                value="<?php echo e($item->id); ?>" <?php echo e((isset($expense->category_id) && $expense->category_id == $item->id) ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php echo $errors->first('category_id', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('amount') ? 'has-error' : ''); ?>">
    <label for="amount" class="control-label"><?php echo e('Amount'); ?></label>
    <input class="form-control" name="amount" type="number" id="amount" value="<?php echo e(isset($expense->amount) ? $expense->amount : ''); ?>">
    <?php echo $errors->first('amount', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('note') ? 'has-error' : ''); ?>">
    <label for="note" class="control-label"><?php echo e('Note'); ?></label>
    <textarea class="form-control" rows="5" name="note" type="textarea" id="note"><?php echo e(isset($expense->note) ? $expense->note : ''); ?></textarea>
    <?php echo $errors->first('note', '<p class="help-block">:message</p>'); ?>

</div>

<div class="form-group <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
    <label for="status" class="control-label"><?php echo e('Status *'); ?></label>
    <select class="form-control" name="status">
        <option value="1" <?php echo e((isset($expense->status) && $expense->status == 1) ? 'selected' : ''); ?>>Active</option>
        <option value="0" <?php echo e((isset($expense->status) && $expense->status == 0) ? 'selected' : ''); ?>>InActive</option>
    </select>
    <?php echo $errors->first('status', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH D:\sohan\wiztecbd_project\aximer_inventory\resources\views/backend/expense/form.blade.php ENDPATH**/ ?>