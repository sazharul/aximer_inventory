<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <label for="name" class="control-label"><?php echo e('Name'); ?></label>
    <input class="form-control" name="name" type="text" id="name" value="<?php echo e(isset($expensecategory->name) ? $expensecategory->name : ''); ?>">
    <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
    <label for="status" class="control-label"><?php echo e('Status *'); ?></label>
    <select class="form-control" name="status">
        <option value="1" <?php echo e((isset($product->status) && $product->status == 1) ? 'selected' : ''); ?>>Active</option>
        <option value="0" <?php echo e((isset($product->status) && $product->status == 0) ? 'selected' : ''); ?>>InActive</option>
    </select>
    <?php echo $errors->first('status', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH D:\sohan\wiztecbd_project\aximer_inventory\resources\views/backend/expense-category/form.blade.php ENDPATH**/ ?>